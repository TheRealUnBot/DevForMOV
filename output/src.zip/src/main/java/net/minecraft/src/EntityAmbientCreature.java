package net.minecraft.src;

public abstract class EntityAmbientCreature extends EntityLiving implements IAnimals {
	
}
