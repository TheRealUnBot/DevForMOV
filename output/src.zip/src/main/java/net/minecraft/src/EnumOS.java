package net.minecraft.src;

public enum EnumOS {
	LINUX, SOLARIS, WINDOWS, MACOS, UNKNOWN;
}
