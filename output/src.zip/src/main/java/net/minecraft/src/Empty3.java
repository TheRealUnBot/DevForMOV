package net.minecraft.src;

public class Empty3 {

}
